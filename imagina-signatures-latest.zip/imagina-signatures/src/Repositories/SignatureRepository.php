<?php
/**
 * Signature repository.
 *
 * @package ImaginaSignatures\Repositories
 */

declare(strict_types=1);

namespace ImaginaSignatures\Repositories;

use ImaginaSignatures\Models\Signature;

defined( 'ABSPATH' ) || exit;

/**
 * Data access for `imgsig_signatures`.
 *
 * Methods that fetch by user ID enforce ownership at the SQL level —
 * REST controllers always go through `find_owned_by()` so a malicious
 * `id` parameter can't surface another user's row.
 *
 * Sorting is hard-coded to a small allow-list to keep injection
 * surfaces minimal; clients pick from {@see ALLOWED_ORDER_BY}.
 *
 * Not declared `final` so PHPUnit 9 can produce mock doubles for
 * controller integration tests.
 *
 * @since 1.0.0
 */
class SignatureRepository extends BaseRepository {

	/**
	 * Whitelist of orderable columns.
	 *
	 * @var string[]
	 */
	public const ALLOWED_ORDER_BY = [ 'updated_at', 'created_at', 'name' ];

	/**
	 * Columns selected for list summaries (no LONGTEXT blobs).
	 */
	private const SUMMARY_COLUMNS = 'id, user_id, name, preview_url, template_id, link_mode, status, schema_version, html_cache IS NOT NULL AS has_html, compiled_at, created_at, updated_at';

	/**
	 * SQL condition for "the stored HTML does not describe the current
	 * design": never compiled, or compiled before the last edit.
	 */
	private const STALE_CONDITION = '(html_cache IS NULL OR compiled_at IS NULL OR compiled_at < updated_at)';

	/**
	 * Per-request cache of owned rows, keyed `"{id}:{user_id}"`, so the
	 * same row isn't re-read by the controller after the service loaded
	 * it. Invalidated on every write to that id.
	 *
	 * @var array<string, Signature>
	 */
	private array $owned_cache = [];

	/**
	 * @inheritDoc
	 */
	protected function table(): string {
		return $this->wpdb->prefix . 'imgsig_signatures';
	}

	/**
	 * Fetches by primary key.
	 *
	 * @since 1.0.0
	 *
	 * @param int $id Primary key.
	 *
	 * @return Signature|null
	 */
	public function find( int $id ): ?Signature {
		$row = $this->wpdb->get_row(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$this->wpdb->prepare( "SELECT * FROM {$this->table()} WHERE id = %d", $id ),
			ARRAY_A
		);

		return is_array( $row ) ? Signature::from_row( $row ) : null;
	}

	/**
	 * Fetches when the row is owned by the given user.
	 *
	 * Always prefer this over {@see find()} from REST controllers — it
	 * folds the ownership check into the query, eliminating a TOCTOU
	 * window between fetch and check.
	 *
	 * @since 1.0.0
	 *
	 * @param int $signature_id Primary key.
	 * @param int $user_id      Owner's user ID.
	 *
	 * @return Signature|null
	 */
	public function find_owned_by( int $signature_id, int $user_id ): ?Signature {
		$cache_key = $signature_id . ':' . $user_id;
		if ( isset( $this->owned_cache[ $cache_key ] ) ) {
			return $this->owned_cache[ $cache_key ];
		}

		$row = $this->wpdb->get_row(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$this->wpdb->prepare(
				"SELECT * FROM {$this->table()} WHERE id = %d AND user_id = %d",
				$signature_id,
				$user_id
			),
			ARRAY_A
		);

		if ( ! is_array( $row ) ) {
			return null;
		}

		$signature                       = Signature::from_row( $row );
		$this->owned_cache[ $cache_key ] = $signature;
		return $signature;
	}

	/**
	 * Moves every signature of `$from_user_id` to `$to_user_id`.
	 *
	 * @since 1.0.40
	 *
	 * @param int $from_user_id Current owner.
	 * @param int $to_user_id   New owner.
	 *
	 * @return int Rows updated.
	 */
	public function reassign_user( int $from_user_id, int $to_user_id ): int {
		$this->owned_cache = [];
		$rows              = $this->wpdb->update(
			$this->table(),
			[ 'user_id' => $to_user_id ],
			[ 'user_id' => $from_user_id ],
			[ '%d' ],
			[ '%d' ]
		);
		return is_int( $rows ) ? $rows : 0;
	}

	/**
	 * Deletes every signature of a user.
	 *
	 * @since 1.0.40
	 *
	 * @param int $user_id Owner.
	 *
	 * @return int Rows deleted.
	 */
	public function delete_by_user( int $user_id ): int {
		$this->owned_cache = [];
		$rows              = $this->wpdb->delete( $this->table(), [ 'user_id' => $user_id ], [ '%d' ] );
		return is_int( $rows ) ? $rows : 0;
	}

	/**
	 * Cheap ownership probe (`SELECT 1`) for permission callbacks.
	 *
	 * @since 1.0.40
	 *
	 * @param int $signature_id Primary key.
	 * @param int $user_id      Owner's user ID.
	 *
	 * @return bool
	 */
	public function exists_owned_by( int $signature_id, int $user_id ): bool {
		if ( isset( $this->owned_cache[ $signature_id . ':' . $user_id ] ) ) {
			return true;
		}

		$found = $this->wpdb->get_var(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$this->wpdb->prepare(
				"SELECT 1 FROM {$this->table()} WHERE id = %d AND user_id = %d LIMIT 1",
				$signature_id,
				$user_id
			)
		);

		return null !== $found;
	}

	/**
	 * Owner of a signature (`SELECT user_id`), 0 when it doesn't exist —
	 * the cheap probe of the "edit on behalf" permission check (1.3.0).
	 *
	 * @since 1.3.0
	 *
	 * @param int $signature_id Primary key.
	 *
	 * @return int
	 */
	public function owner_of( int $signature_id ): int {
		if ( $signature_id <= 0 ) {
			return 0;
		}
		return (int) $this->wpdb->get_var(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$this->wpdb->prepare( "SELECT user_id FROM {$this->table()} WHERE id = %d", $signature_id )
		);
	}

	/**
	 * Drops cached rows for an id (after any write to it).
	 *
	 * @param int $signature_id Primary key.
	 *
	 * @return void
	 */
	private function forget( int $signature_id ): void {
		foreach ( array_keys( $this->owned_cache ) as $key ) {
			if ( 0 === strpos( $key, $signature_id . ':' ) ) {
				unset( $this->owned_cache[ $key ] );
			}
		}
	}

	/**
	 * Returns true when the user already has at least one signature
	 * row stamped with the given template_id. Used by the bulk-apply
	 * flow to skip rows that would otherwise duplicate.
	 *
	 * @since 1.1.0
	 *
	 * @param int $user_id     Owner.
	 * @param int $template_id The template the signature was seeded from.
	 *
	 * @return bool
	 */
	public function user_has_signature_from_template( int $user_id, int $template_id ): bool {
		$count = $this->wpdb->get_var(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$this->wpdb->prepare(
				"SELECT COUNT(*) FROM {$this->table()} WHERE user_id = %d AND template_id = %d",
				$user_id,
				$template_id
			)
		);
		return (int) $count > 0;
	}

	/**
	 * The user's most recently updated signature stamped with
	 * `$template_id` (the one template assignment updates), or null.
	 *
	 * @since 1.3.0
	 *
	 * @param int $user_id     Owner.
	 * @param int $template_id Template.
	 *
	 * @return Signature|null
	 */
	public function find_latest_by_user_and_template( int $user_id, int $template_id ): ?Signature {
		$row = $this->wpdb->get_row(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$this->wpdb->prepare(
				"SELECT * FROM {$this->table()} WHERE user_id = %d AND template_id = %d ORDER BY (link_mode = 'linked') DESC, updated_at DESC, id DESC LIMIT 1",
				$user_id,
				$template_id
			),
			ARRAY_A
		);

		return is_array( $row ) ? Signature::from_row( $row ) : null;
	}

	/**
	 * Signatures linked to a template, in id order, after a cursor —
	 * one propagation batch.
	 *
	 * @since 1.3.0
	 *
	 * @param int $template_id Template.
	 * @param int $after_id    Return rows with an id above this (0 = from the start).
	 * @param int $limit       Batch size.
	 *
	 * @return Signature[]
	 */
	public function find_linked_to_template( int $template_id, int $after_id, int $limit ): array {
		$rows = $this->wpdb->get_results(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$this->wpdb->prepare(
				"SELECT * FROM {$this->table()} WHERE template_id = %d AND link_mode = %s AND id > %d ORDER BY id ASC LIMIT %d",
				$template_id,
				Signature::LINK_LINKED,
				$after_id,
				max( 1, $limit )
			),
			ARRAY_A
		);

		if ( ! is_array( $rows ) ) {
			return [];
		}
		return array_map( [ Signature::class, 'from_row' ], $rows );
	}

	/**
	 * Number of signatures linked to a template.
	 *
	 * @since 1.3.0
	 *
	 * @param int $template_id Template.
	 *
	 * @return int
	 */
	public function count_linked_to_template( int $template_id ): int {
		return (int) $this->wpdb->get_var(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$this->wpdb->prepare(
				"SELECT COUNT(*) FROM {$this->table()} WHERE template_id = %d AND link_mode = %s",
				$template_id,
				Signature::LINK_LINKED
			)
		);
	}

	/**
	 * Detaches every signature linked to a template (it was deleted):
	 * each keeps its current design. `updated_at` is left alone — the
	 * design did not change, so the stored HTML stays valid.
	 *
	 * @since 1.3.0
	 *
	 * @param int $template_id Template.
	 *
	 * @return int Rows updated.
	 */
	public function detach_all_from_template( int $template_id ): int {
		$this->owned_cache = [];
		$rows              = $this->wpdb->update(
			$this->table(),
			[ 'link_mode' => Signature::LINK_DETACHED ],
			[
				'template_id' => $template_id,
				'link_mode'   => Signature::LINK_LINKED,
			],
			[ '%s' ],
			[ '%d', '%s' ]
		);
		return is_int( $rows ) ? $rows : 0;
	}

	/**
	 * Most user ids bound into one `IN (...)` list.
	 */
	public const ID_CHUNK = 500;

	/**
	 * Marks the stored HTML of every signature of `$user_ids` (null =
	 * every user) as outdated, because something it was compiled from
	 * changed outside the signature itself: the owner's profile or WP
	 * user fields, their groups, the brand kit, the compliance footer,
	 * the banner campaigns or the profile field mapping (1.3.0).
	 *
	 * Clears `compiled_at` — {@see STALE_CONDITION} then holds — and
	 * nothing else: `json_content`, `html_cache` (still served by the
	 * install page and the Outlook add-in until recompiled) and
	 * `updated_at` are untouched, so listing order and the implicit
	 * primary signature ("most recently updated") never move.
	 * Idempotent: rows that are already outdated are not rewritten.
	 * One UPDATE (per {@see ID_CHUNK} users).
	 *
	 * @since 1.3.0
	 *
	 * @param int[]|null $user_ids Owners, or null for everyone.
	 *
	 * @return int Rows marked.
	 */
	public function mark_html_outdated( ?array $user_ids ): int {
		$this->owned_cache = [];

		if ( null === $user_ids ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- plugin table, no input.
			$rows = $this->wpdb->query( "UPDATE {$this->table()} SET compiled_at = NULL WHERE compiled_at IS NOT NULL" );
			return is_int( $rows ) ? $rows : 0;
		}

		$marked = 0;
		foreach ( array_chunk( self::positive_ids( $user_ids ), self::ID_CHUNK ) as $chunk ) {
			$placeholders = implode( ',', array_fill( 0, count( $chunk ), '%d' ) );
			$rows         = $this->wpdb->query(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders built above.
				$this->wpdb->prepare( "UPDATE {$this->table()} SET compiled_at = NULL WHERE compiled_at IS NOT NULL AND user_id IN ({$placeholders})", ...$chunk )
			);
			$marked += is_int( $rows ) ? $rows : 0;
		}
		return $marked;
	}

	/**
	 * Narrow rows (no LONGTEXT blobs, plus `html_hash`) of every signature
	 * owned by `$user_ids`, newest first per user — what the team console
	 * needs to resolve each user's primary signature and its deployment
	 * state without one query per user. One SELECT per {@see ID_CHUNK}
	 * users.
	 *
	 * @since 1.3.0
	 *
	 * @param int[] $user_ids Owners.
	 *
	 * @return array<int, Signature[]> User id => signatures (updated_at DESC, id DESC).
	 */
	public function summaries_for_users( array $user_ids ): array {
		$out     = [];
		$columns = self::SUMMARY_COLUMNS . ', html_hash';
		foreach ( array_chunk( self::positive_ids( $user_ids ), self::ID_CHUNK ) as $chunk ) {
			$placeholders = implode( ',', array_fill( 0, count( $chunk ), '%d' ) );
			$rows         = $this->wpdb->get_results(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders built above.
				$this->wpdb->prepare( "SELECT {$columns} FROM {$this->table()} WHERE user_id IN ({$placeholders}) ORDER BY user_id ASC, updated_at DESC, id DESC", ...$chunk ),
				ARRAY_A
			);
			foreach ( is_array( $rows ) ? $rows : [] as $row ) {
				$signature                    = Signature::from_row( $row );
				$out[ $signature->user_id ][] = $signature;
			}
		}
		return $out;
	}

	/**
	 * Unique positive integer ids.
	 *
	 * @param array<int, mixed> $ids Raw ids.
	 *
	 * @return int[]
	 */
	private static function positive_ids( array $ids ): array {
		$out = [];
		foreach ( $ids as $id ) {
			$id = is_numeric( $id ) ? (int) $id : 0;
			if ( $id > 0 ) {
				$out[ $id ] = $id;
			}
		}
		return array_values( $out );
	}

	/**
	 * Signatures (of every user) whose stored HTML is missing or older
	 * than their design — the team console recompiles these. Summary
	 * projection (no LONGTEXT blobs), in id order.
	 *
	 * Supported `$args`:
	 *  - `template_id`      int   Only rows of this template.
	 *  - `include_archived` bool  Include archived rows (default false).
	 *  - `after_id`         int   Cursor: only rows with a higher id.
	 *  - `page`             int   1-indexed page (default 1).
	 *  - `per_page`         int   Default 20, max 100.
	 *
	 * @since 1.3.0
	 *
	 * @param array<string, mixed> $args Filters / pagination.
	 *
	 * @return Signature[]
	 */
	public function find_stale( array $args = [] ): array {
		[ $where_sql, $values ] = $this->build_stale_where( $args );

		$per_page = max( 1, min( 100, (int) ( $args['per_page'] ?? 20 ) ) );
		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );
		$columns  = self::SUMMARY_COLUMNS;

		$rows = $this->wpdb->get_results(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$this->wpdb->prepare(
				"SELECT {$columns} FROM {$this->table()} WHERE {$where_sql} ORDER BY id ASC LIMIT %d OFFSET %d",
				...array_merge( $values, [ $per_page, ( $page - 1 ) * $per_page ] )
			),
			ARRAY_A
		);

		if ( ! is_array( $rows ) ) {
			return [];
		}
		return array_map( [ Signature::class, 'from_row' ], $rows );
	}

	/**
	 * Counts the rows {@see find_stale()} pages through.
	 *
	 * @since 1.3.0
	 *
	 * @param array<string, mixed> $args Same filters as find_stale().
	 *
	 * @return int
	 */
	public function count_stale( array $args = [] ): int {
		[ $where_sql, $values ] = $this->build_stale_where( $args );

		return (int) $this->wpdb->get_var(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			$this->wpdb->prepare( "SELECT COUNT(*) FROM {$this->table()} WHERE {$where_sql}", ...$values )
		);
	}

	/**
	 * WHERE clause + values for the stale listing.
	 *
	 * @param array<string, mixed> $args Filters.
	 *
	 * @return array{0: string, 1: array<int, mixed>}
	 */
	private function build_stale_where( array $args ): array {
		// `1 = %d` keeps prepare() happy when no other value is bound.
		$clauses = [ self::STALE_CONDITION, '1 = %d' ];
		$values  = [ 1 ];

		if ( empty( $args['include_archived'] ) ) {
			$clauses[] = 'status <> %s';
			$values[]  = Signature::STATUS_ARCHIVED;
		}

		if ( ! empty( $args['template_id'] ) ) {
			$clauses[] = 'template_id = %d';
			$values[]  = (int) $args['template_id'];
		}

		if ( ! empty( $args['after_id'] ) ) {
			$clauses[] = 'id > %d';
			$values[]  = (int) $args['after_id'];
		}

		return [ implode( ' AND ', $clauses ), $values ];
	}

	/**
	 * Lists signatures owned by the given user.
	 *
	 * Supported `$args`:
	 *  - `status`   string|null  Filter by status.
	 *  - `search`   string|null  Case-insensitive partial match on name.
	 *  - `page`     int          1-indexed page (default 1).
	 *  - `per_page` int          Items per page (default 20, max 100).
	 *  - `order_by` string       Column from {@see ALLOWED_ORDER_BY}.
	 *  - `order`    string       `asc` | `desc` (default `desc`).
	 *  - `fields`   string       `all` (default) | `summary` — summary skips
	 *                            the json_content / html_cache LONGTEXTs.
	 *
	 * @since 1.0.0
	 *
	 * @param int                  $user_id Owner.
	 * @param array<string, mixed> $args    Filter/pagination args.
	 *
	 * @return Signature[]
	 */
	public function find_by_user( int $user_id, array $args = [] ): array {
		[ $where_sql, $where_values ] = $this->build_where( $user_id, $args );

		$order_by = in_array( (string) ( $args['order_by'] ?? '' ), self::ALLOWED_ORDER_BY, true )
			? (string) $args['order_by']
			: 'updated_at';

		$order    = 'asc' === strtolower( (string) ( $args['order'] ?? 'desc' ) ) ? 'ASC' : 'DESC';
		$per_page = max( 1, min( 100, (int) ( $args['per_page'] ?? 20 ) ) );
		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );
		$offset   = ( $page - 1 ) * $per_page;

		$columns = 'summary' === ( $args['fields'] ?? 'all' ) ? self::SUMMARY_COLUMNS : '*';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$sql = $this->wpdb->prepare(
			"SELECT {$columns} FROM {$this->table()} WHERE {$where_sql} ORDER BY {$order_by} {$order} LIMIT %d OFFSET %d",
			...array_merge( $where_values, [ $per_page, $offset ] )
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $this->wpdb->get_results( $sql, ARRAY_A );

		if ( ! is_array( $rows ) ) {
			return [];
		}

		$out = [];
		foreach ( $rows as $row ) {
			$out[] = Signature::from_row( $row );
		}
		return $out;
	}

	/**
	 * Counts signatures matching the same filter set as
	 * {@see find_by_user()}.
	 *
	 * @since 1.0.0
	 *
	 * @param int                  $user_id Owner.
	 * @param array<string, mixed> $args    Filter args.
	 *
	 * @return int
	 */
	public function count_by_user( int $user_id, array $args = [] ): int {
		[ $where_sql, $where_values ] = $this->build_where( $user_id, $args );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$count = $this->wpdb->get_var(
			$this->wpdb->prepare(
				"SELECT COUNT(*) FROM {$this->table()} WHERE {$where_sql}",
				...$where_values
			)
		);

		return (int) $count;
	}

	/**
	 * Inserts a new signature row.
	 *
	 * `$data` must include `user_id`, `name`, `json_content`. Other
	 * fields fall back to defaults defined here.
	 *
	 * @since 1.0.0
	 *
	 * @param array<string, mixed> $data Field values.
	 *
	 * @return Signature
	 *
	 * @throws \RuntimeException When the INSERT fails or the row cannot be read back.
	 */
	public function insert( array $data ): Signature {
		$now = $this->now();

		$row = [
			'user_id'        => (int) ( $data['user_id'] ?? 0 ),
			'name'           => (string) ( $data['name'] ?? '' ),
			'json_content'   => (string) ( $data['json_content'] ?? '' ),
			'html_cache'     => $data['html_cache'] ?? null,
			'preview_url'    => $data['preview_url'] ?? null,
			'template_id'    => isset( $data['template_id'] ) ? (int) $data['template_id'] : null,
			'status'         => (string) ( $data['status'] ?? Signature::STATUS_DRAFT ),
			'schema_version' => (string) ( $data['schema_version'] ?? '1.0' ),
			'created_at'     => $now,
			'updated_at'     => $now,
			'html_text'      => $data['html_text'] ?? null,
			'html_hash'      => $data['html_hash'] ?? null,
			// A compile sent with the create belongs to this exact row
			// state, so it is stamped with the same instant as updated_at —
			// unless it was compiled from inputs that changed since
			// (`html_outdated`, 1.3.0): then it stays outdated.
			'compiled_at'    => isset( $data['html_cache'] ) && empty( $data['html_outdated'] ) ? $now : null,
			// 1.3.0: only a row with a template can follow it.
			'link_mode'      => Signature::LINK_LINKED === ( $data['link_mode'] ?? '' ) && isset( $data['template_id'] )
				? Signature::LINK_LINKED
				: Signature::LINK_DETACHED,
		];

		$inserted = $this->wpdb->insert(
			$this->table(),
			$row,
			[ '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
		);

		// `$wpdb->insert` returns false on actual SQL failure (vs zero
		// rows affected, which is impossible for INSERT). Surface the
		// last_error explicitly — until 1.0.26 a failed insert silently
		// produced a Signature model with `id = 0` that the caller
		// happily round-tripped to the user as "Saved".
		if ( false === $inserted ) {
			throw new \RuntimeException(
				'Database INSERT failed for imgsig_signatures: ' . ( $this->wpdb->last_error ?: 'unknown error' )
			);
		}

		$insert_id = (int) $this->wpdb->insert_id;
		if ( $insert_id <= 0 ) {
			throw new \RuntimeException( 'Database INSERT returned no insert_id for imgsig_signatures.' );
		}

		// Re-fetch from the DB instead of trusting `$row`. This catches
		// silent corruption (charset mismatch, column truncation,
		// missing column after a failed migration) — the in-memory
		// `$row` would otherwise look fine even when the persisted
		// row differs from what we tried to write.
		$persisted = $this->find( $insert_id );
		if ( null === $persisted ) {
			throw new \RuntimeException(
				sprintf( 'Inserted row %d disappeared on read-back. The save did not persist.', $insert_id )
			);
		}
		return $persisted;
	}

	/**
	 * Updates an existing signature row.
	 *
	 * Only fields present in `$data` are written; everything else stays
	 * untouched. `updated_at` is bumped automatically.
	 *
	 * @since 1.0.0
	 *
	 * @param int                  $id   Primary key.
	 * @param array<string, mixed> $data Partial field map.
	 *
	 * @return Signature|null  The updated row, or null when no row matched.
	 *
	 * @throws \RuntimeException When the UPDATE fails at the database layer.
	 */
	public function update( int $id, array $data ): ?Signature {
		$updatable = [
			'name'           => '%s',
			'json_content'   => '%s',
			'html_cache'     => '%s',
			'preview_url'    => '%s',
			'template_id'    => '%d',
			'status'         => '%s',
			'schema_version' => '%s',
			'html_text'      => '%s',
			'html_hash'      => '%s',
			'link_mode'      => '%s',
		];

		$update  = [];
		$formats = [];
		foreach ( $updatable as $column => $format ) {
			if ( array_key_exists( $column, $data ) ) {
				$update[ $column ] = $data[ $column ];
				$formats[]         = $format;
			}
		}

		if ( empty( $update ) ) {
			return $this->find( $id );
		}

		$update['updated_at'] = $this->now();
		$formats[]            = '%s';

		// HTML compiled alongside this write describes exactly this row
		// state: stamp it with the same instant so it isn't seen as stale.
		// HTML compiled from inputs that changed since (`html_outdated`,
		// 1.3.0) is stored but stays outdated.
		if ( array_key_exists( 'html_cache', $data ) ) {
			$update['compiled_at'] = empty( $data['html_outdated'] ) ? $update['updated_at'] : null;
			$formats[]             = '%s';
		}

		$this->forget( $id );

		// `$wpdb->update` returns false on SQL failure or int (rows
		// affected) on success. Zero rows affected is fine — it means
		// the new values matched the stored values, NOT that the write
		// silently dropped. Treating false as a hard error and zero as
		// success matches the WP REST conventions.
		$result = $this->wpdb->update( $this->table(), $update, [ 'id' => $id ], $formats, [ '%d' ] );

		if ( false === $result ) {
			throw new \RuntimeException(
				sprintf(
					'Database UPDATE failed for signature %d: %s',
					$id,
					$this->wpdb->last_error ?: 'unknown error'
				)
			);
		}

		// Read-back: the canonical answer for "what's actually on disk"
		// is the row we read after writing, not the values we tried to
		// write. The service layer compares hashes to detect silent
		// corruption.
		return $this->find( $id );
	}

	/**
	 * Deletes a row by primary key.
	 *
	 * @since 1.0.0
	 *
	 * @param int $id Primary key.
	 *
	 * @return bool True when at least one row was deleted.
	 */
	public function delete( int $id ): bool {
		$this->forget( $id );
		$rows = $this->wpdb->delete( $this->table(), [ 'id' => $id ], [ '%d' ] );
		return is_int( $rows ) && $rows > 0;
	}

	/**
	 * Builds the WHERE clause and bound values for list/count queries.
	 *
	 * @since 1.0.0
	 *
	 * @param int                  $user_id Owner.
	 * @param array<string, mixed> $args    Filter args.
	 *
	 * @return array{0: string, 1: array<int, mixed>}
	 */
	private function build_where( int $user_id, array $args ): array {
		$clauses = [ 'user_id = %d' ];
		$values  = [ $user_id ];

		if ( ! empty( $args['status'] ) && in_array( (string) $args['status'], Signature::STATUSES, true ) ) {
			$clauses[] = 'status = %s';
			$values[]  = (string) $args['status'];
		}

		if ( ! empty( $args['search'] ) ) {
			$clauses[] = 'name LIKE %s';
			$values[]  = '%' . $this->wpdb->esc_like( (string) $args['search'] ) . '%';
		}

		return [ implode( ' AND ', $clauses ), $values ];
	}
}
