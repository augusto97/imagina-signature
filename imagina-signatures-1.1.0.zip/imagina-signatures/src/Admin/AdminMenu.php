<?php
/**
 * Admin menu registrar.
 *
 * @package ImaginaSignatures\Admin
 */

declare(strict_types=1);

namespace ImaginaSignatures\Admin;

use ImaginaSignatures\Admin\Pages\EditorPage;
use ImaginaSignatures\Setup\CapabilitiesInstaller;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the plugin's wp-admin menu structure.
 *
 * Three top-level destinations all back onto the same React admin
 * app ({@see AdminAppPage}) — different wp-admin URLs just tell the
 * app which "page" to render (Signatures / Templates / Settings).
 *
 * The Editor remains a dedicated wp-admin page that mounts the
 * iframe (full-screen React editor) — separate bundle, separate
 * config global. Reached only via the New / Edit links from the
 * Signatures listing, so it isn't surfaced in the side menu.
 *
 * @since 1.0.0
 */
final class AdminMenu {

	public const MENU_SLUG      = 'imagina-signatures';
	public const TEMPLATES_SLUG = 'imagina-signatures-templates';
	public const SETTINGS_SLUG  = 'imagina-signatures-settings';
	public const EDITOR_SLUG    = 'imagina-signatures-editor';

	/**
	 * @var AdminAppPage
	 */
	private AdminAppPage $signatures_page;

	/**
	 * @var AdminAppPage
	 */
	private AdminAppPage $templates_page;

	/**
	 * @var AdminAppPage
	 */
	private AdminAppPage $settings_page;

	/**
	 * @var EditorPage
	 */
	private EditorPage $editor_page;

	/**
	 * @param AdminAppPage $signatures_page Renderer for the signatures listing.
	 * @param AdminAppPage $templates_page  Renderer for the templates page.
	 * @param AdminAppPage $settings_page   Renderer for the storage settings page.
	 * @param EditorPage   $editor_page     Renderer for the editor iframe host.
	 */
	public function __construct(
		AdminAppPage $signatures_page,
		AdminAppPage $templates_page,
		AdminAppPage $settings_page,
		EditorPage $editor_page
	) {
		$this->signatures_page = $signatures_page;
		$this->templates_page  = $templates_page;
		$this->settings_page   = $settings_page;
		$this->editor_page     = $editor_page;
	}

	/**
	 * Hooks the menu registration into WordPress.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function boot(): void {
		add_action( 'admin_menu', [ $this, 'register_menus' ] );
	}

	/**
	 * Adds the top-level menu and submenus.
	 *
	 * Collects each `add_*_page` hook suffix and wires the asset
	 * enqueuer to load the React bundle on those screens only.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function register_menus(): void {
		$signatures_hook = add_menu_page(
			__( 'Imagina Signatures', 'imagina-signatures' ),
			__( 'Imagina Signatures', 'imagina-signatures' ),
			CapabilitiesInstaller::CAP_USE,
			self::MENU_SLUG,
			[ $this->signatures_page, 'render' ],
			'dashicons-email-alt',
			30
		);

		add_submenu_page(
			self::MENU_SLUG,
			__( 'My Signatures', 'imagina-signatures' ),
			__( 'My Signatures', 'imagina-signatures' ),
			CapabilitiesInstaller::CAP_USE,
			self::MENU_SLUG,
			[ $this->signatures_page, 'render' ]
		);

		$templates_hook = add_submenu_page(
			self::MENU_SLUG,
			__( 'Templates', 'imagina-signatures' ),
			__( 'Templates', 'imagina-signatures' ),
			CapabilitiesInstaller::CAP_USE,
			self::TEMPLATES_SLUG,
			[ $this->templates_page, 'render' ]
		);

		$settings_hook = add_submenu_page(
			self::MENU_SLUG,
			__( 'Storage Settings', 'imagina-signatures' ),
			__( 'Settings', 'imagina-signatures' ),
			CapabilitiesInstaller::CAP_MANAGE_STORAGE,
			self::SETTINGS_SLUG,
			[ $this->settings_page, 'render' ]
		);

		// Editor: registered with empty parent so it's hidden from the
		// menu but reachable via admin.php?page=...
		$editor_hook = add_submenu_page(
			'',
			__( 'Edit Signature', 'imagina-signatures' ),
			__( 'Edit Signature', 'imagina-signatures' ),
			CapabilitiesInstaller::CAP_USE,
			self::EDITOR_SLUG,
			[ $this->editor_page, 'render' ]
		);

		// Wire asset loading. `add_*_page` returns false when the
		// current user can't see the page; skip those entries.
		$hook_pages = array_filter(
			[
				is_string( $signatures_hook ) ? $signatures_hook : null => 'signatures',
				is_string( $templates_hook ) ? $templates_hook : null   => 'templates',
				is_string( $settings_hook ) ? $settings_hook : null     => 'settings',
			],
			static function ( $key ): bool {
				return null !== $key && '' !== $key;
			},
			ARRAY_FILTER_USE_KEY
		);

		( new AdminAssetEnqueuer( $hook_pages ) )->boot();

		if ( is_string( $editor_hook ) && '' !== $editor_hook ) {
			( new EditorAssetEnqueuer( $editor_hook ) )->boot();

			// Hidden pages (empty parent) never get a `$title`, so core's
			// admin-header.php passes null to strip_tags() and logs a PHP
			// 8.1+ deprecation on every editor load. Give it one.
			add_action(
				'load-' . $editor_hook,
				static function (): void {
					global $title;
					// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- core reads it for the <title>.
					$title = __( 'Edit Signature', 'imagina-signatures' );
				}
			);
		}
	}
}
